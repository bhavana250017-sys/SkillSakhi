# SkillSakhi — SDG 8 Internship Discovery Prototype

A student project prototype for career exploration and role-specific learning searches, aligned with the spirit of **UN Sustainable Development Goal 8: Decent Work and Economic Growth**.

## Features
- Responsive, polished home page, internship listing, and SDG 8 impact page
- Search by role, company, skills, or description
- Filter by domain and work mode
- YouTube search links generated from internship titles and required skills
- Sample listings clearly labelled as demo data

## Run on Windows
1. Open a terminal in this folder.
2. (Optional) Create a virtual environment: `py -m venv .venv`
3. Activate it in PowerShell: `.\.venv\Scripts\Activate.ps1`
4. Install dependencies: `python -m pip install -r requirements.txt`
5. Start the app: `python app.py`
6. Open `http://127.0.0.1:5000/`

## Important
All companies, internships, and stipend values are fictional demo data, not live or verified vacancies. YouTube buttons open search results and do not guarantee that a specific video has been vetted. SkillSakhi is not affiliated with or endorsed by the United Nations. Verify employers and opportunities independently before sharing personal information.
