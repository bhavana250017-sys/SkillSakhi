from flask import Flask, render_template, request
from urllib.parse import quote_plus

app = Flask(__name__)

# Fictional demo listings only; these are not live or verified vacancies.
INTERNSHIPS = [
    {"id": 1, "title": "Python Development Intern", "company": "NovaTech (Demo)", "domain": "Software", "mode": "Hybrid", "location": "Chennai", "skills": ["Python", "Flask", "Git"], "duration": "8 weeks", "stipend": "₹8,000/month (demo)", "level": "Beginner", "description": "Build beginner-friendly Python features and learn software development workflows."},
    {"id": 2, "title": "Web Development Intern", "company": "PixelSpring (Demo)", "domain": "Web Development", "mode": "Remote", "location": "India", "skills": ["HTML", "CSS", "JavaScript"], "duration": "10 weeks", "stipend": "₹10,000/month (demo)", "level": "Beginner", "description": "Create responsive web pages and practise accessible front-end development."},
    {"id": 3, "title": "AI/ML Intern", "company": "BrightMind Labs (Demo)", "domain": "AI & Data", "mode": "Hybrid", "location": "Chennai", "skills": ["Python", "Machine Learning", "Pandas"], "duration": "12 weeks", "stipend": "₹12,000/month (demo)", "level": "Intermediate", "description": "Explore datasets, train simple models, and document experiments."},
    {"id": 4, "title": "Data Analyst Intern", "company": "DataNest (Demo)", "domain": "Analytics", "mode": "Remote", "location": "India", "skills": ["Excel", "SQL", "Python"], "duration": "8 weeks", "stipend": "₹9,000/month (demo)", "level": "Beginner", "description": "Clean sample datasets, build reports, and communicate useful insights."},
    {"id": 5, "title": "UI/UX Design Intern", "company": "Kindred Studio (Demo)", "domain": "Design", "mode": "Hybrid", "location": "Chennai", "skills": ["Figma", "Wireframing", "User Research"], "duration": "6 weeks", "stipend": "₹7,000/month (demo)", "level": "Beginner", "description": "Practise user research, wireframes, and inclusive interface design."},
    {"id": 6, "title": "Cybersecurity Intern", "company": "SafeStack (Demo)", "domain": "Cybersecurity", "mode": "On-site", "location": "Chennai", "skills": ["Networking", "Linux", "Security Basics"], "duration": "10 weeks", "stipend": "₹11,000/month (demo)", "level": "Intermediate", "description": "Learn defensive security concepts and basic security documentation."},
]

def prepare(item):
    result = item.copy()
    query = f"{result['title']} {' '.join(result['skills'])} tutorial for beginners"
    result['youtube_url'] = 'https://www.youtube.com/results?search_query=' + quote_plus(query)
    return result

@app.route('/')
def home():
    return render_template('index.html', featured=[prepare(x) for x in INTERNSHIPS[:3]], total=len(INTERNSHIPS))

@app.route('/internships')
def internships():
    q = request.args.get('q', '').strip().lower()
    domain = request.args.get('domain', '')
    mode = request.args.get('mode', '')
    matches = []
    for item in INTERNSHIPS:
        searchable = ' '.join([item['title'], item['company'], item['domain'], item['location'], item['description'], *item['skills']]).lower()
        if q and q not in searchable: continue
        if domain and domain != item['domain']: continue
        if mode and mode != item['mode']: continue
        matches.append(prepare(item))
    return render_template('internships.html', internships=matches, q=q, selected_domain=domain, selected_mode=mode, domains=sorted({x['domain'] for x in INTERNSHIPS}), modes=sorted({x['mode'] for x in INTERNSHIPS}))

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
